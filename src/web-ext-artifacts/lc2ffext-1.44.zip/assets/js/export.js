// /**
//  * Show a notification when we get messages from the content script.
//  */
// browser.runtime.onMessage.addListener((message) => {
//   browser.notifications.create({
//     type: "basic",
//     title: "Message from the page",
//     message: message.content
//   });
// });


// const button1 = document.querySelector("#function-notify");

// button1.addEventListener("click", () => {
//   window.notify("Message from the page script!");
// });

// const button2 = document.querySelector("#object-notify");

// button2.addEventListener("click", () => {
//   window.messenger.notify("Message from the page script!");
// });
