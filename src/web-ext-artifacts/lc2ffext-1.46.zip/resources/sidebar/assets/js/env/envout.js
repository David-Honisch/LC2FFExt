document.write("Betriebssystem:<br /><b>"+ yourOS +"</b><br>");
document.write("Javascript aktiviert: <b> "+ javaOK + "</b><br>");
document.write("Cookies annehmbar: <b> "+ cookiesOK + "</b><br>");
document.write("Browser Sprache:<b> "+ browsLang + "</b><br>");
document.write("Browser Version: <b>"+majorVers+""+ "" + "</b><br>");
document.write("Bildschirmaufl&ouml;sung: <b>"+width+" </b>x<b> "+height+"</b><br>");
document.write("Farbtiefe: <b>" + colordepth + "</b>");
//document.writeln("</br>");